from uuid import UUID

from sqlalchemy import text
from sqlalchemy.orm import Session


class SellerRepository:
    @staticmethod
    def get_profile(db: Session, seller_id: UUID):
        return db.execute(text("""
            SELECT user_id, store_name, store_slug, description, logo_url, gstin,
                   verification_status, commission_rate, created_at, updated_at
              FROM seller_profiles
             WHERE user_id = :seller_id
        """), {"seller_id": seller_id}).mappings().first()

    @staticmethod
    def create_profile(db: Session, seller_id: UUID, payload: dict):
        row = db.execute(text("""
            INSERT INTO seller_profiles (user_id, store_name, store_slug, description, logo_url, gstin)
            VALUES (:seller_id, :store_name, :store_slug, :description, :logo_url, :gstin)
            RETURNING user_id, store_name, store_slug, description, logo_url, gstin,
                      verification_status, commission_rate, created_at, updated_at
        """), {"seller_id": seller_id, **payload}).mappings().first()
        db.commit()
        return row

    @staticmethod
    def update_profile(db: Session, seller_id: UUID, payload: dict):
        if not payload:
            return SellerRepository.get_profile(db, seller_id)
        assignments = ", ".join(f"{key} = :{key}" for key in payload)
        row = db.execute(text(f"""
            UPDATE seller_profiles
               SET {assignments}
             WHERE user_id = :seller_id
            RETURNING user_id, store_name, store_slug, description, logo_url, gstin,
                      verification_status, commission_rate, created_at, updated_at
        """), {"seller_id": seller_id, **payload}).mappings().first()
        db.commit()
        return row

    @staticmethod
    def get_category(db: Session, category_id: UUID):
        return db.execute(text("""
            SELECT id FROM categories WHERE id = :id AND is_active = TRUE
        """), {"id": category_id}).first()

    @staticmethod
    def brand_exists(db: Session, brand_id: UUID):
        return db.execute(text("SELECT id FROM brands WHERE id = :id"), {"id": brand_id}).first()

    @staticmethod
    def create_product(db: Session, seller_id: UUID, payload: dict):
        """Create the product and all submitted variants atomically."""
        variants = payload.pop("variants", [])
        try:
            row = db.execute(text("""
                INSERT INTO products (seller_id, category_id, brand_id, title, slug, description, status)
                VALUES (:seller_id, :category_id, :brand_id, :title, :slug, :description, :status)
                RETURNING id, seller_id, category_id, brand_id, title, slug, description, status,
                          avg_rating, review_count, created_at, updated_at
            """), {"seller_id": seller_id, **payload}).mappings().first()

            for variant in variants:
                db.execute(text("""
                    INSERT INTO product_variants
                        (product_id, sku, name, mrp, price, stock_qty, is_active)
                    VALUES
                        (:product_id, :sku, :name, :mrp, :price, :stock_qty, :is_active)
                """), {"product_id": row["id"], **variant})

            # Fetch the same enriched shape used by GET /products/{product_id}
            # so it satisfies SellerProductOut (category/brand names and stock totals).
            product = SellerRepository.get_product(db, seller_id, row["id"])
            if product is None:
                raise RuntimeError("Created product could not be retrieved")

            db.commit()
            return product
        except Exception:
            db.rollback()
            raise

    @staticmethod
    def list_products(db: Session, seller_id: UUID, page: int, page_size: int):
        params = {"seller_id": seller_id, "limit": page_size, "offset": (page - 1) * page_size}
        rows = db.execute(text("""
            SELECT p.id, p.seller_id, p.category_id, c.name AS category_name,
                   p.brand_id, b.name AS brand_name, p.title, p.slug, p.description,
                   p.status, p.avg_rating, p.review_count, p.created_at, p.updated_at,
                   COALESCE(v.variants_count, 0)::integer AS variants_count,
                   COALESCE(v.total_stock, 0)::integer AS total_stock,
                   COALESCE(v.total_stock, 0) > 0 AS in_stock,
                   img.url AS primary_image_url
              FROM products p
              JOIN categories c ON c.id = p.category_id
              LEFT JOIN brands b ON b.id = p.brand_id
              LEFT JOIN LATERAL (
                  SELECT COUNT(*) AS variants_count, COALESCE(SUM(stock_qty), 0) AS total_stock
                    FROM product_variants pv WHERE pv.product_id = p.id AND pv.is_active = TRUE
              ) v ON TRUE
              LEFT JOIN LATERAL (
                  SELECT url FROM product_images pi
                   WHERE pi.product_id = p.id AND pi.is_primary = TRUE
                   ORDER BY pi.sort_order LIMIT 1
              ) img ON TRUE
             WHERE p.seller_id = :seller_id AND p.deleted_at IS NULL
             ORDER BY p.created_at DESC, p.id
             LIMIT :limit OFFSET :offset
        """), params).mappings().all()
        total = db.execute(text("""
            SELECT COUNT(*) FROM products
             WHERE seller_id = :seller_id AND deleted_at IS NULL
        """), {"seller_id": seller_id}).scalar_one()
        return rows, total

    @staticmethod
    def get_product(db: Session, seller_id: UUID, product_id: UUID):
        return db.execute(text("""
            SELECT p.id, p.seller_id, p.category_id, c.name AS category_name,
                   p.brand_id, b.name AS brand_name, p.title, p.slug, p.description,
                   p.status, p.avg_rating, p.review_count, p.created_at, p.updated_at,
                   COALESCE(v.variants_count, 0)::integer AS variants_count,
                   COALESCE(v.total_stock, 0)::integer AS total_stock,
                   COALESCE(v.total_stock, 0) > 0 AS in_stock,
                   img.url AS primary_image_url
              FROM products p
              JOIN categories c ON c.id = p.category_id
              LEFT JOIN brands b ON b.id = p.brand_id
              LEFT JOIN LATERAL (
                  SELECT COUNT(*) AS variants_count, COALESCE(SUM(stock_qty), 0) AS total_stock
                    FROM product_variants pv WHERE pv.product_id = p.id AND pv.is_active = TRUE
              ) v ON TRUE
              LEFT JOIN LATERAL (
                  SELECT url FROM product_images pi
                   WHERE pi.product_id = p.id AND pi.is_primary = TRUE
                   ORDER BY pi.sort_order LIMIT 1
              ) img ON TRUE
             WHERE p.id = :product_id AND p.seller_id = :seller_id AND p.deleted_at IS NULL
        """), {"product_id": product_id, "seller_id": seller_id}).mappings().first()

    @staticmethod
    def update_product(db: Session, seller_id: UUID, product_id: UUID, payload: dict):
        if not payload:
            return SellerRepository.get_product(db, seller_id, product_id)
        assignments = ", ".join(f"{key} = :{key}" for key in payload)
        row = db.execute(text(f"""
            UPDATE products SET {assignments}
             WHERE id = :product_id AND seller_id = :seller_id AND deleted_at IS NULL
            RETURNING id
        """), {"product_id": product_id, "seller_id": seller_id, **payload}).first()
        if not row:
            db.rollback()
            return None
        db.commit()
        return SellerRepository.get_product(db, seller_id, product_id)

    @staticmethod
    def archive_product(db: Session, seller_id: UUID, product_id: UUID):
        row = db.execute(text("""
            UPDATE products
               SET deleted_at = now(), status = 'archived'
             WHERE id = :product_id AND seller_id = :seller_id AND deleted_at IS NULL
            RETURNING id
        """), {"product_id": product_id, "seller_id": seller_id}).first()
        db.commit()
        return row is not None
