from uuid import UUID

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.repositories.seller_repo import SellerRepository


class SellerService:
    @staticmethod
    def get_profile(db: Session, seller_id: UUID):
        row = SellerRepository.get_profile(db, seller_id)
        if not row:
            raise HTTPException(status_code=404, detail="Seller profile not found")
        return row

    @staticmethod
    def create_profile(db: Session, seller_id: UUID, payload: dict):
        return SellerRepository.create_profile(db, seller_id, payload)

    @staticmethod
    def update_profile(db: Session, seller_id: UUID, payload: dict):
        row = SellerRepository.update_profile(db, seller_id, payload)
        if not row:
            raise HTTPException(status_code=404, detail="Seller profile not found")
        return row

    @staticmethod
    def _ensure_profile(db: Session, seller_id: UUID):
        profile = SellerRepository.get_profile(db, seller_id)
        if not profile:
            raise HTTPException(status_code=409, detail="Create your seller profile before managing products")
        return profile

    @staticmethod
    def _validate_product_refs(db: Session, payload: dict):
        if "category_id" in payload and not SellerRepository.get_category(db, payload["category_id"]):
            raise HTTPException(status_code=400, detail="Category does not exist or is inactive")
        if payload.get("brand_id") is not None and not SellerRepository.brand_exists(db, payload["brand_id"]):
            raise HTTPException(status_code=400, detail="Brand does not exist")

    @staticmethod
    def _validate_status(profile, status: str | None):
        if status == "active" and profile["verification_status"] != "approved":
            raise HTTPException(status_code=403, detail="Only approved sellers can publish active products")

    @staticmethod
    def create_product(db: Session, seller_id: UUID, payload: dict):
        profile = SellerService._ensure_profile(db, seller_id)
        SellerService._validate_product_refs(db, payload)
        SellerService._validate_status(profile, payload.get("status"))
        variants = payload.get("variants", [])
        if payload.get("status") == "active" and not variants:
            raise HTTPException(status_code=400, detail="At least one variant is required to publish a product")
        # Do not mutate the caller's payload; repository removes variants before inserting products.
        return SellerRepository.create_product(db, seller_id, dict(payload))

    @staticmethod
    def list_products(db: Session, seller_id: UUID, page: int, page_size: int):
        SellerService._ensure_profile(db, seller_id)
        rows, total = SellerRepository.list_products(db, seller_id, page, page_size)
        return {"items": rows, "total": total, "page": page, "page_size": page_size}

    @staticmethod
    def get_product(db: Session, seller_id: UUID, product_id: UUID):
        SellerService._ensure_profile(db, seller_id)
        row = SellerRepository.get_product(db, seller_id, product_id)
        if not row:
            raise HTTPException(status_code=404, detail="Product not found")
        return row

    @staticmethod
    def update_product(db: Session, seller_id: UUID, product_id: UUID, payload: dict):
        profile = SellerService._ensure_profile(db, seller_id)
        SellerService._validate_product_refs(db, payload)
        SellerService._validate_status(profile, payload.get("status"))
        row = SellerRepository.update_product(db, seller_id, product_id, payload)
        if not row:
            raise HTTPException(status_code=404, detail="Product not found")
        return row

    @staticmethod
    def archive_product(db: Session, seller_id: UUID, product_id: UUID):
        SellerService._ensure_profile(db, seller_id)
        if not SellerRepository.archive_product(db, seller_id, product_id):
            raise HTTPException(status_code=404, detail="Product not found")
