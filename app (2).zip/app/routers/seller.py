from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, Query, Response, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.deps import require_role, get_current_user
from app.schemas.seller import (
    SellerProfileCreate,
    SellerProfileOut,
    SellerProfileUpdate,
    SellerProductCreate,
    SellerProductOut,
    SellerProductPage,
    SellerProductUpdate,
)
from app.services.seller_service import SellerService

router = APIRouter(prefix="/seller", tags=["seller"])
seller_only = require_role("seller")


@router.get("/profile", response_model=SellerProfileOut)
def get_seller_profile(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return SellerService.get_profile(db, user["id"])


@router.post("/profile", response_model=SellerProfileOut,
             status_code=status.HTTP_201_CREATED)
def create_seller_profile(
    payload: SellerProfileCreate,
    db: Session = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    return SellerService.create_profile(
        db, user["id"], payload.model_dump()
    )


@router.put("/profile", response_model=SellerProfileOut)
def update_seller_profile(
    payload: SellerProfileUpdate,
    db: Session = Depends(get_db),
    user: dict = Depends(seller_only),
):
    return SellerService.update_profile(db, user["id"], payload.model_dump(exclude_unset=True))


@router.get("/products", response_model=SellerProductPage)
def list_seller_products(
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
    user: dict = Depends(seller_only),
):
    return SellerService.list_products(db, user["id"], limit, offset)


@router.post("/products", response_model=SellerProductOut, status_code=status.HTTP_201_CREATED)
def create_seller_product(
    payload: SellerProductCreate,
    db: Session = Depends(get_db),
    user: dict = Depends(seller_only),
):
    return SellerService.create_product(db, user["id"], payload.model_dump())


@router.get("/products/{product_id}", response_model=SellerProductOut)
def get_seller_product(
    product_id: UUID,
    db: Session = Depends(get_db),
    user: dict = Depends(seller_only),
):
    return SellerService.get_product(db, user["id"], product_id)


@router.put("/products/{product_id}", response_model=SellerProductOut)
def update_seller_product(
    product_id: UUID,
    payload: SellerProductUpdate,
    db: Session = Depends(get_db),
    user: dict = Depends(seller_only),
):
    return SellerService.update_product(db, user["id"], product_id, payload.model_dump(exclude_unset=True))


@router.delete("/products/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
def archive_seller_product(
    product_id: UUID,
    db: Session = Depends(get_db),
    user: dict = Depends(seller_only),
):
    SellerService.archive_product(db, user["id"], product_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
